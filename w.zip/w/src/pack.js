const pack = (prefix) => {
    return `*PACKS:*
    
*DARK DOMIMA 🐊🚩*

Belle delphine : https://photos.app.goo.gl/Jr4Qk1dFSJepPdRc7 

Pack1: https://photos.app.goo.gl/phyRpNFLcAtsknfJ7 

Kitty kum: https://photos.app.goo.gl/gNxLbJHGVzeWY9iS9 

Misaki Your Waifu: https://photos.app.goo.gl/M9nyHdonAJu5GRjZ9 

pack: https://photos.app.goo.gl/SrogbCbnanL2PJQn7 

Love Lilah : https://photos.app.goo.gl/TBbkjGGdAVHjPFt5A 
`
}
exports.pack = pack
