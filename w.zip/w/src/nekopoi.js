const nekopoi = () => { 
	return `       
Você deseja acessar / assistir Nekopoi sem baixar VPN? Clique no link abaixo, role para baixo e digite concordar e conectar.

https://www.hidemyass-freeproxy.com/proxy/id-id/aHR0cHM6Ly9uZWtvcG9pLmNhcmUv

*Goste de assistir*`
}
exports.nekopoi = nekopoi