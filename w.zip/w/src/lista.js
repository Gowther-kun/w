const lista = () => { 
	return `
	MANUTENÇÃO`
}
exports.lista = lista