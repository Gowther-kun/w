const lista = () => { 
	return `
	#TESTE....
`
}
exports.lista = lista