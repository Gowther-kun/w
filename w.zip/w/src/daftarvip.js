const daftarvip = (prefix) => { 
	return `
	
*PREÇO DE LISTA VIP :*

-So precisa ser gente boa
-Não se chamar gabi

*SE QUER REGISTAR VIP :*

*Proprietário do bate-papo BOT :*

_wa.me/5584987777164 ou digite *${prefix}owner*_`
}
exports.daftarvip = daftarvip