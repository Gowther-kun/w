const daftarvip = (prefix) => { 
	return `
	
*PREÇO DE LISTA VIP :*

-Mamadinha no Criador...

}
exports.daftarvip = daftarvip
