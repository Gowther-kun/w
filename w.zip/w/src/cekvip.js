const cekvip = () => { 
	return `           
──────────────────
*Nome do bot* :  GOTEBOT
──────────────────
        『 *𝐕𝐈𝐏 𝐔𝐒𝐄𝐑* 』
──────────────────
• *Status*    : *ATIVO*
────────────────── 
*Status Bot:* *Online*
──────────────────

*VOCE E UM MEMBRO PREMIUM* 🐊🚩`
}
exports.cekvip = cekvip