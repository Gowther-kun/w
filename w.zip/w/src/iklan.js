const iklan = () => { 
	return `           
╔══✪〘 IKLAN 〙✪══
--EM TESTE--
`
}
exports.iklan = iklan