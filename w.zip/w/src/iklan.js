const iklan = () => { 
	return `           
╔══✪〘 IKLAN 〙✪══
--MANUTENÇÃO
`
}
exports.iklan = iklan
